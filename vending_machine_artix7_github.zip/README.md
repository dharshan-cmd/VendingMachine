# Vending Machine — Xilinx Vivado / Artix-7

A beginner-friendly Verilog FSM vending-machine project intended for simulation
and implementation in Xilinx Vivado on an Artix-7 FPGA.

## Default behavior

- Product price: **15 units**
- Accepted coins: **5** and **10** units
- Insert 5 + 10, or 10 + 5: dispense one product
- Insert 10 + 10: dispense one product and return 5 units change
- Cancel: clear the current credit
- `credit_led[4:0]`: current credit in binary
- `state_led[1:0]`: current FSM state
- `dispense_led`: product-dispense pulse
- `change_led`: 5-unit change pulse

## Files

- `rtl/vending_machine.v` — vending-machine finite-state machine
- `rtl/button_pulse.v` — input synchronizer and rising-edge pulse generator
- `rtl/vending_machine_top.v` — FPGA top-level wrapper
- `sim/tb_vending_machine.v` — simulation testbench
- `constraints/board_template.xdc` — pin-constraint template (must be completed)

## Create the Vivado project

1. Open **Vivado** and select **Create Project**.
2. Choose **RTL Project** and add the three files in `rtl/` as design sources.
3. Add `sim/tb_vending_machine.v` as a simulation source.
4. Select the exact Artix-7 FPGA part fitted to your board.
5. Set `vending_machine_top` as the top module.
6. Add `constraints/board_template.xdc` after replacing placeholders with the
   correct pin names and I/O standards from your board's official master XDC.
7. Run **Run Synthesis**, **Run Implementation**, then **Generate Bitstream**.

## Important hardware notes

- The XDC file is deliberately a template. Artix-7 boards use different FPGA
  packages and pinouts. Never guess pin assignments.
- The example `button_pulse` module synchronizes button inputs and creates a
  one-clock pulse, but it does not remove mechanical switch bounce. For reliable
  physical push-buttons, add a debounce circuit.
- The design assumes one clean coin pulse at a time. If both coin inputs are
  high together, the 5-unit input has priority.
- The outputs are one-clock pulses. Use LEDs only for logic demonstration;
  a real motor/solenoid mechanism requires a suitable driver circuit and
  appropriate electrical protection.

## Suggested GitHub description

A Verilog-based vending machine controller implemented as a finite-state machine
for Xilinx Vivado and Artix-7 FPGA, with simulation testbench and XDC template.
