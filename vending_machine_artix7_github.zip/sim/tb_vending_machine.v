`timescale 1ns / 1ps

module tb_vending_machine;
    reg clk = 0;
    reg reset = 1;
    reg coin_5 = 0;
    reg coin_10 = 0;
    reg cancel = 0;
    wire dispense;
    wire change_5;
    wire [1:0] state_led;
    wire [4:0] credit_led;

    vending_machine dut (
        .clk(clk), .reset(reset), .coin_5(coin_5), .coin_10(coin_10),
        .cancel(cancel), .dispense(dispense), .change_5(change_5),
        .state_led(state_led), .credit_led(credit_led)
    );

    always #5 clk = ~clk;

    task insert_coin5;
        begin
            @(negedge clk); coin_5 = 1;
            @(negedge clk); coin_5 = 0;
        end
    endtask

    task insert_coin10;
        begin
            @(negedge clk); coin_10 = 1;
            @(negedge clk); coin_10 = 0;
        end
    endtask

    initial begin
        $display("Starting vending machine test...");
        repeat (2) @(negedge clk);
        reset = 0;

        // 5 + 10 = 15: dispense, no change.
        insert_coin5();
        insert_coin10();
        @(negedge clk);
        if (credit_led !== 5'd0) $display("ERROR: credit did not reset after vend");

        // 10 + 10 = 20: dispense and return 5 change.
        insert_coin10();
        @(negedge clk);
        if (!dispense || !change_5)
            $display("ERROR: expected dispense and 5-unit change pulse");

        // Cancel returns the machine to zero credit.
        insert_coin5();
        @(negedge clk); cancel = 1;
        @(negedge clk); cancel = 0;
        if (credit_led !== 5'd0) $display("ERROR: cancel failed");

        $display("Test sequence completed.");
        #20 $finish;
    end
endmodule
