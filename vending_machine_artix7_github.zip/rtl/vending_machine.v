`timescale 1ns / 1ps
// Vending Machine FSM for Xilinx Artix-7 FPGA (Vivado)
// Product price: 15 units. Accepted coins: 5 and 10 units.
// If total reaches 15: dispense one product.
// If total reaches 20: dispense one product and return 5 units change.
// coin_5 and coin_10 should be one-clock pulses (debounce buttons externally
// or use the included edge-pulse module in the top-level design).

module vending_machine (
    input  wire clk,
    input  wire reset,       // Active-high synchronous reset
    input  wire coin_5,
    input  wire coin_10,
    input  wire cancel,
    output reg  dispense,
    output reg  change_5,
    output reg  [1:0] state_led,
    output reg  [4:0] credit_led
);

    localparam [1:0] IDLE       = 2'b00;
    localparam [1:0] CREDIT_5   = 2'b01;
    localparam [1:0] CREDIT_10  = 2'b10;
    localparam [1:0] CREDIT_15  = 2'b11;

    reg [1:0] state;
    reg [1:0] next_state;
    reg [4:0] credit;
    reg [4:0] next_credit;

    // State and credit register
    always @(posedge clk) begin
        if (reset) begin
            state  <= IDLE;
            credit <= 5'd0;
        end else begin
            state  <= next_state;
            credit <= next_credit;
        end
    end

    // Next-state and credit logic
    always @* begin
        next_state  = state;
        next_credit = credit;

        if (cancel) begin
            next_state  = IDLE;
            next_credit = 5'd0;
        end else begin
            case (state)
                IDLE: begin
                    if (coin_5) begin
                        next_credit = 5'd5;
                        next_state  = CREDIT_5;
                    end else if (coin_10) begin
                        next_credit = 5'd10;
                        next_state  = CREDIT_10;
                    end
                end

                CREDIT_5: begin
                    if (coin_5) begin
                        next_credit = 5'd10;
                        next_state  = CREDIT_10;
                    end else if (coin_10) begin
                        next_credit = 5'd15;
                        next_state  = CREDIT_15;
                    end
                end

                CREDIT_10: begin
                    if (coin_5) begin
                        next_credit = 5'd15;
                        next_state  = CREDIT_15;
                    end else if (coin_10) begin
                        // 20 units inserted: vend and return 5 units.
                        next_credit = 5'd0;
                        next_state  = IDLE;
                    end
                end

                CREDIT_15: begin
                    // The product is dispensed on reaching this state.
                    next_credit = 5'd0;
                    next_state  = IDLE;
                end

                default: begin
                    next_state  = IDLE;
                    next_credit = 5'd0;
                end
            endcase
        end
    end

    // One-clock output pulses, based on the accepted transaction.
    // Reaching 15 from CREDIT_5 with a 10-unit coin or from CREDIT_10
    // with a 5-unit coin dispenses the product.
    always @* begin
        dispense = 1'b0;
        change_5 = 1'b0;

        if (!reset && !cancel) begin
            if ((state == CREDIT_5  && coin_10) ||
                (state == CREDIT_10 && coin_5)  ||
                (state == CREDIT_10 && coin_10)) begin
                dispense = 1'b1;
            end

            if (state == CREDIT_10 && coin_10)
                change_5 = 1'b1;
        end
    end

    // LEDs expose current credit and state for FPGA demonstration.
    always @* begin
        credit_led = credit;
        state_led  = state;
    end

endmodule
