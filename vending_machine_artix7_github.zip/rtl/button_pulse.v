`timescale 1ns / 1ps
// Simple synchronizer + rising-edge pulse generator.
// This does NOT debounce mechanical switch bounce; add a debounce circuit
// or use a clean pulse source for physical push-buttons.

module button_pulse (
    input  wire clk,
    input  wire reset,
    input  wire button_in,
    output wire pulse_out
);
    reg sync_0, sync_1, button_d;

    always @(posedge clk) begin
        if (reset) begin
            sync_0  <= 1'b0;
            sync_1  <= 1'b0;
            button_d <= 1'b0;
        end else begin
            sync_0   <= button_in;
            sync_1   <= sync_0;
            button_d <= sync_1;
        end
    end

    assign pulse_out = sync_1 & ~button_d;
endmodule
