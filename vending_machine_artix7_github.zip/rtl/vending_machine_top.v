`timescale 1ns / 1ps
// Example board top-level.
// Map clk, reset_btn, coin5_btn, coin10_btn and cancel_btn to your
// specific Artix-7 board pins in the XDC file.

module vending_machine_top (
    input  wire clk,
    input  wire reset_btn,
    input  wire coin5_btn,
    input  wire coin10_btn,
    input  wire cancel_btn,
    output wire dispense_led,
    output wire change_led,
    output wire [1:0] state_led,
    output wire [4:0] credit_led
);
    wire reset_pulse, coin5_pulse, coin10_pulse, cancel_pulse;

    button_pulse u_reset (
        .clk(clk), .reset(1'b0), .button_in(reset_btn), .pulse_out(reset_pulse)
    );
    button_pulse u_coin5 (
        .clk(clk), .reset(reset_pulse), .button_in(coin5_btn), .pulse_out(coin5_pulse)
    );
    button_pulse u_coin10 (
        .clk(clk), .reset(reset_pulse), .button_in(coin10_btn), .pulse_out(coin10_pulse)
    );
    button_pulse u_cancel (
        .clk(clk), .reset(reset_pulse), .button_in(cancel_btn), .pulse_out(cancel_pulse)
    );

    vending_machine u_vending_machine (
        .clk(clk),
        .reset(reset_pulse),
        .coin_5(coin5_pulse),
        .coin_10(coin10_pulse),
        .cancel(cancel_pulse),
        .dispense(dispense_led),
        .change_5(change_led),
        .state_led(state_led),
        .credit_led(credit_led)
    );
endmodule
