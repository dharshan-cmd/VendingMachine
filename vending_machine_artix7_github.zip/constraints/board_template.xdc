## TEMPLATE ONLY — replace every placeholder with the pin assignments
## from the master XDC for your exact Artix-7 development board.
## Do not program the FPGA with guessed pin locations or I/O standards.

## Example format:
## set_property PACKAGE_PIN <PIN_NAME> [get_ports clk]
## set_property IOSTANDARD LVCMOS33 [get_ports clk]
## create_clock -period 10.000 -name sys_clk [get_ports clk]

## Ports to constrain:
## clk
## reset_btn
## coin5_btn
## coin10_btn
## cancel_btn
## dispense_led
## change_led
## state_led[0], state_led[1]
## credit_led[0] through credit_led[4]
